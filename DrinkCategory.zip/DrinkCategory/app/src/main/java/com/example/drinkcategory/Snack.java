package com.example.drinkcategory;

public class Snack {
    private String name;
    private String description;
    private int imageResourceId;

    public static final Snack[] snacks = {
            new Snack("Sernik", "Pyszny domowy sernik z polewą.", R.drawable.sernik),
            new Snack("Brownie", "Mocno czekoladowe ciastko.", R.drawable.brownie),
            new Snack("Kanapka", "Świeża bułka z szynką i serem.", R.drawable.sandwich)
    };

    public Snack(String name, String description, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.imageResourceId = imageResourceId;
    }

    public String getName() { return name; }
    public String getDescription() { return description; }
    public int getImageResourceId() { return imageResourceId; }
    public String toString() { return this.name; }
}