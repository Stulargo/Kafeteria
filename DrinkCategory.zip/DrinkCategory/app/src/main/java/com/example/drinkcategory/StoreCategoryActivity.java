package com.example.drinkcategory;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class StoreCategoryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ListView listView = new ListView(this);
        setContentView(listView);

        String[] lokalizacje = {
                "Coffeina Centrum - ul. Jasna 10",
                "Coffeina Dworzec - ul. Główna 5",
                "Coffeina Park - al. Różana 15"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                lokalizacje
        );

        listView.setAdapter(adapter);
    }
}