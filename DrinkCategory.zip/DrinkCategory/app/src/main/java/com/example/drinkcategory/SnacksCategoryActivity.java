package com.example.drinkcategory;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class SnacksCategoryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_snacks_category);

        ListView listSnacks = findViewById(R.id.list_snacks);

        ArrayAdapter<Snack> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, Snack.snacks);
        listSnacks.setAdapter(adapter);

        listSnacks.setOnItemClickListener((parent, view, position, id) -> {
            Intent intent = new Intent(SnacksCategoryActivity.this, DrinkActivity.class);
            intent.putExtra(DrinkActivity.EXTRA_DRINKID, (int) id);
            intent.putExtra("type", "snack");
        });
    }
}