package com.example.drinkcategory;

public class Drink {
    private String name;
    private String description;
    private int imageResourceId;

    public static final Drink[] drinks =
            {
              new Drink("Latte","Czarne espresso z gorącym mlekiem i mleczną pianką.",R.drawable.latte),
              new Drink("Cappucino", "Czarne espresso z dużą ilością spienionego mleka.", R.drawable.cappucino),
              new Drink("Espresso", "Czarna kawa ze świeżo zmielonym ziarnem najzwyższej jakości.",R.drawable.filter)
            };

    public Drink(String name, String description, int imageResourceId) {
        this.name = name;
        this.description = description;
        this.imageResourceId = imageResourceId;
    }

    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    public int getImageResourceId() {
        return imageResourceId;
    }
    public String toString()
    {
        return this.name;
    }
}
