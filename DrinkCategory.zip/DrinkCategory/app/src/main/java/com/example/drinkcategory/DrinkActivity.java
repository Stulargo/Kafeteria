package com.example.drinkcategory;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DrinkActivity extends AppCompatActivity {
    public static final String EXTRA_DRINKID = "drinkId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drink);

        int drinkId = getIntent().getIntExtra(EXTRA_DRINKID, 0);
        String type = getIntent().getStringExtra("type");

        if ("snack".equals(type)) {
            Snack snack = Snack.snacks[drinkId];
            ((TextView) findViewById(R.id.name)).setText(snack.getName());
            ((TextView) findViewById(R.id.descirption)).setText(snack.getDescription());
            ((ImageView) findViewById(R.id.photo)).setImageResource(snack.getImageResourceId());
        } else {
            Drink drink = Drink.drinks[drinkId];
            ((TextView) findViewById(R.id.name)).setText(drink.getName());
            ((TextView) findViewById(R.id.descirption)).setText(drink.getDescription());
            ((ImageView) findViewById(R.id.photo)).setImageResource(drink.getImageResourceId());
        }
    }
}