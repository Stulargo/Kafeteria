package com.example.drinkcategory;

public class Store {
    private String name;
    private String address;
    private String openingHours;

    public static final Store[] stores = {
            new Store("Coffeina Centrum", "ul. Marszałkowska 10, Warszawa", "8:00 - 22:00"),
            new Store("Coffeina Park", "al. Pokoju 5, Kraków", "9:00 - 20:00"),
            new Store("Coffeina Starówka", "Rynek 12, Gdańsk", "10:00 - 21:00")
    };

    public Store(String name, String address, String openingHours) {
        this.name = name;
        this.address = address;
        this.openingHours = openingHours;
    }

    public String getName() { return name; }
    public String getAddress() { return address; }
    public String getOpeningHours() { return openingHours; }
    public String toString() { return this.name; }
}